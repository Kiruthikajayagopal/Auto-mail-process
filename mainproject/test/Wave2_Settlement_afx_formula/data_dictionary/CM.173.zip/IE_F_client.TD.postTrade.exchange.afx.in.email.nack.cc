<!-- amdg egalon galone2 -->
<Operand Code="ScalarString">;</Operand>

